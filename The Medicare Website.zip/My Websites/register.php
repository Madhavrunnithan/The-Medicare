<?php
    include('./connection.php');
    if(isset($_POST['submit'])){
        $user = $_POST['usname'];
        $pswd = $_POST['pswd'];

        try {
            if( $user != null && $pswd != null){
                $query = mysqli_query($con,"insert into pharmacist(uname,password) values('$user','$pswd');");
                if($query){
                        echo "<script>alert('Registered Successfully.Login to Use our services'); window.location.assign('./index.php');</script>";
                }
                else{
                    echo "<script>alert('Registration Failed')</script>";
                }
            }
            else{
                echo "<script>alert('Fill the fields to continue')</script>";
            }
        } catch (Exception $e) {
            echo "<script>alert('Unsuccessful')</script>";
            die("Query Failed: " . $e->getMessage());
        }
    }
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
    </style>
    <link rel="stylesheet" href="./loginstyle.css">
    <link rel="icon" href="./icons8-medical-48.png" type="image/icon type">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body>
    <div class ="main">
        <div class="texts"><h1>Welcome to <br><span style="font-size: 50px;">Medi</span><span style="color: khaki;font-size: 50px;">Care</span></h1></div>
        <div class="container">
            
            <form method="post">
                <h1>Register Here</h1>
                <div class = "form-group" id="labeldiv" >
                    <label for="">Username</label>
                    <input type="text" class="form-control" name ="usname" id = "username" required >
                </div>
                <div class = "form-group" id="labeldiv">
                    <label for="">Password</label>
                    <input type="password" class="form-control" name ="pswd" id ="password" required >
                </div>
                <div class="submitclass" name = "register">
                    <button type="submit" class="btn" style="background-color: darkkhaki;" name="submit">Register</button>
                </div>
                
            </form>   
        </div>
    </div>
</body>
</html>
