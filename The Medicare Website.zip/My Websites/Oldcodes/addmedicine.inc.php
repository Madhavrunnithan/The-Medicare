<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $mname = $_POST["mname"];
    $quantity = $_POST["quantity"];
    $category = $_POST["category"];
    $rate = $_POST["rate"];

    try {
        require_once "dbh.inc.php";
        $query = "INSERT INTO medicine (name,quantity,category,rate) VALUES (?, ?, ?, ?);";

        $stmt = $pdo->prepare($query);
        $stmt->execute([$mname,$quantity,$category,$rate]);

        $pdo = null;
        $stmt = null;
        header("Location: ../addmed.html");
        die();

    } catch (PDOException $e) {
        die("Query Failed: " . $e->getMessage());
    }
}
else{
    header("Location: ../addmed.html");
}