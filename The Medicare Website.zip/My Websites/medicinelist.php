<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicine List</title>
    <link rel="icon" href="./icons8-medical-48.png" type="image/icon type">
    <link rel="stylesheet" href="./manipulate_style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<style>
    td{
        padding: 10px;

    }
</style>
</head>
<body class="main">
    <div class="titles">
        <a href="./home_user.html"><h2>Medicine List</h2></a>
    </div>
     <div class="tablediv">
        <table>
            <tr>
                <th>M-Id</th>
                <th>Medicine Name</th>
                <th>Quantity</th>
                <th>Category</th>
                <th>Rate</th>
                <th colspan="2">Operations</th>
            </tr>
            <?php
                include('./connection.php');
                $query = "select id,name,quantity,category,rate from medicine";
                $result = mysqli_query($con,$query);
                if($result -> num_rows > 0){
                    while ($row = $result-> fetch_assoc()){
                        echo "
                        <tr>
                            <td>{$row['id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['quantity']}</td>
                            <td>{$row['category']}</td>
                            <td>{$row['rate']}</td>
                            <td style = ''></td>
                            <td>
                                <form action='buy.php' method='post' style='display:inline;'>
                                    <input type='hidden' name='id' value='{$row['id']}'>
                                    <input type='hidden' name='mname' value='{$row['name']}'>
                                    <input type='hidden' name='quantity' value='{$row['quantity']}'>
                                    <input type='hidden' name='category' value='{$row['category']}'>
                                    <input type='hidden' name='rt' value='{$row['rate']}'>
                                    <input type='number' name='nqt' required>
                                    <button type='submit' class='editbutton' name = 'sell' style = '
                                        padding-left: 20px;
                                        padding-right: 20px;
                                        border-radius: 10px;
                                        padding-top : 5px;
                                        padding-bottom : 5px;
                                        background-color:green;
                                        font-size : 18px;
                                    '>Sell</button>
                                </form>
                            </td>
                        </tr>
                    ";
                        
                    }
                    echo "</table>";
                }
                else{
                    echo "0 result";
                }
            ?>
        </table>
        <script>
            function checkdelete(){
                return confirm('Are you sure you want to delete this Medicine Record??')
            }
            </script>
     </div>
</body>
</html>