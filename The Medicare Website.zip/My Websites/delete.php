<?php
    include("connection.php");
    $id = $_GET['id'];
    try {
        $query = "delete from medicine where id = '$id'";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<script>alert('Record Deleted');window.location.assign('./manipulate.php');</script>";
        }
        else{
            echo "<script>alert('Unsuccessful')</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Delete Process Failed')</script>";
        die("Query Failed: " . $e->getMessage());
    }
    
?>