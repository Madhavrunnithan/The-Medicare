<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicine List</title>
    <link rel="icon" href="./icons8-medical-48.png" type="image/icon type">
    <link rel="stylesheet" href="./manipulate_style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<style>
    td{
        padding: 10px;

    }
</style>
</head>
<body class="main">
    <div class="titles">
        <a href="./home.html"><h2>Medicine List</h2></a>
    </div>
     <div class="tablediv">
        <table>
            <tr>
                <th>M-Id</th>
                <th>Medicine Name</th>
                <th>Quantity</th>
                <th>Category</th>
                <th>Rate</th>
                <th colspan="2">Operations</th>
            </tr>
            <?php
                include('./connection.php');
                $query = "select id,name,quantity,category,rate from medicine";
                $result = mysqli_query($con,$query);
                if($result -> num_rows > 0){
                    while ($row = $result-> fetch_assoc()){
                        if($row['quantity'] <= 10){
                            echo "<tr>
                                <td class = 'warning'>". $row["id"] ."</td>
                                <td class = 'warning'>". $row["name"] ."</td>
                                <td class = 'warning'>" . $row["quantity"] ."</td>
                                <td class = 'warning'>" . $row["category"] ."</td>
                                <td class = 'warning'>". $row["rate"] ."</td>
                                <td><a href='update.php?id={$row["id"]}&mn={$row["name"]}&qt={$row["quantity"]}&ct={$row["category"]}&rt={$row["rate"]}' class = 'editbutton'>Edit</a></td>
                                <td><a href = 'delete.php?id={$row["id"]}' onclick = 'return checkdelete()' class = 'deletebutton' >Delete</a></td>
                            </tr>";
                        }
                        else if($row['quantity'] > 10 && $row['quantity'] < 50){
                            echo "<tr>
                                <td class = 'warningyellow'>". $row["id"] ."</td>
                                <td class = 'warningyellow'>". $row["name"] ."</td>
                                <td class = 'warningyellow'>" . $row["quantity"] ."</td>
                                <td class = 'warningyellow'>" . $row["category"] ."</td>
                                <td class = 'warningyellow'>". $row["rate"] ."</td>
                                <td><a href='update.php?id={$row["id"]}&mn={$row["name"]}&qt={$row["quantity"]}&ct={$row["category"]}&rt={$row["rate"]}' class = 'editbutton'>Edit</a></td>
                                <td><a href = 'delete.php?id={$row["id"]}' onclick = 'return checkdelete()' class = 'deletebutton' >Delete</a></td>
                            </tr>";
                        }
                        else{
                            echo "<tr>
                                <td>". $row["id"] ."</td>
                                <td>". $row["name"] ."</td>
                                <td>" . $row["quantity"] ."</td>
                                <td>" . $row["category"] ."</td>
                                <td>". $row["rate"] ."</td>
                                <td><a href='update.php?id={$row["id"]}&mn={$row["name"]}&qt={$row["quantity"]}&ct={$row["category"]}&rt={$row["rate"]}' class = 'editbutton'>Edit</a></td>
                                <td><a href = 'delete.php?id={$row["id"]}' onclick = 'return checkdelete()' class = 'deletebutton' >Delete</a></td>
                            </tr>";
                        }
                        
                    }
                    echo "</table>";
                }
                else{
                    echo "0 result";
                }
            ?>
        </table>
        <script>
            function checkdelete(){
                return confirm('Are you sure you want to delete this Medicine Record??')
            }
            </script>
     </div>
</body>
</html>