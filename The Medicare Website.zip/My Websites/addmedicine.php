<?php
    include('./connection.php');
    if(isset($_POST['submit'])) {
        $mid = $_POST["mid"];
        $mname = $_POST["mname"];
        $quantity = $_POST["quantity"];
        $category = $_POST["category"];
        $rate = $_POST["rate"];
        
        try {
            
            if($mid != null && $mname != null && $quantity != null && $category != null && $rate != null){
                $query = mysqli_query($con,"insert into medicine (id,name,quantity,category,rate) VALUES ('$mid','$mname','$quantity','$category','$rate')");
                if($query){
                    echo "<script>alert('Medicine inserted successfully')</script>";
                }
                else{
                    echo "<script>alert('Unsuccessful')</script>";
                }
            }
            else{
                echo "<script>alert('Unsuccessful')</script>";
            }
        } catch (Exception $e) {
            echo "<script>alert('Unsuccessful')</script>";
            die("Query Failed: " . $e->getMessage());
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Medicine</title>
    <link rel="stylesheet" href="./addmedstyle.css">
    <link rel="icon" href="./icons8-medical-48.png" type="image/icon type">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body class="main">
    <div >
        
        <div class="container">
            <form action="" method="post">

                <h2>Medicine Details</h2>
                <div class="form-group" >
                    <label>Medicine Id:</label>
                    <input type="number" name = "mid" class="form-control">
                </div>
                <div class="form-group" >
                    <label>Medicine Name:</label>
                    <input type="text" name = "mname" class="form-control">
                </div>
                <div class="form-group" >
                    <label>Quantity:</label>
                    <input type="number" name = "quantity"  class="form-control">
                </div>
                <div class="form-group" >
                    <label>Category:</label>
                    <input type="text" name = "category"  class="form-control">
                </div>
                <div class="form-group" >
                    <label>Rate:</label>
                    <input type="number" name = "rate"  class="form-control">
                </div>
                <div class="submitclass">
                    <button type="submit" class="btn" name="submit"><h4>Submit</h4></button>
                </div>
                <div class="back">
                    <button ><a href="./home.html">Back</a></button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>