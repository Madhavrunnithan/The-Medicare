<?php
    include('./connection.php');
    if ($_SERVER['REQUEST_METHOD'] === 'POST'){
        $id = $_POST['id'];
        $quantity = $_POST['quantity'];
        $nqt = $_POST['nqt'];
    
    
        // Now you can use $id, $quantity, and $nqt in your code
       /* echo "Medicine ID: $id<br>";
        echo "Available Quantity: $quantity<br>";
        echo "Quantity to Sell: $nqt<br>";*/
        if($quantity >= $nqt){
            $query = mysqli_query($con,"update medicine set quantity = quantity - '$nqt' where id = '$id';");
            if($query){
                echo "<script>alert('Added to cart');window.location.assign('./medicinelist.php')</script>";
            }
            else{
                echo "<script>alert('Failed to add...!<br>Try again');window.location.assign('./medicinelist.php')</script>";
            }
        }
        else{
            echo "<script>alert('Failed to add...!<br>check stock quantity');window.location.assign('./medicinelist.php')</script>";
        }
    }
?>