<?php
    include('./connection.php');
    $m_id=$_GET['id'];
    $m_name = $_GET['mn'];
    $m_quantity =$_GET['qt'];
    $m_category = $_GET['ct'];
    $m_rate=$_GET['rt'];

    if(isset($_POST['submit'])) {
        $id = $_POST['id'];
        $mname = $_POST["mname"];
        $quantity = $_POST["quantity"];
        $category = $_POST["category"];
        $rate = $_POST["rate"];
        try {
            
            if($mname != null && $quantity != null && $category != null && $rate != null){
                $query = mysqli_query($con,"update medicine set name='$mname',quantity='$quantity',category='$category',rate='$rate' where id = '$id'");
                if($query){
                    echo "<script>alert('Update successfully');window.location.assign('./manipulate.php');</script>";
                    
                }
                else{
                    echo "<script>alert('Unsuccessful')</script>";
                    echo $mname;
                }
            }
            else{
                echo "<script>alert('Unsuccessful')</script>";
            }
        } catch (Exception $e) {
            echo "<script>alert('Unsuccessful')</script>";
            die("Query Failed: " . $e->getMessage());
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Medicine</title>
    <link rel="stylesheet" href="./addmedstyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body class="main">
    <div >
        
        <div class="container">
            <form action="" method="post">

                <h2>Medicine Details</h2>
                <input type="hidden" name="id" value="<?php echo $m_id; ?>">
                <div class="form-group" >
                    <label>Medicine Name</label>
                    <input type="text" name = "mname" class="form-control" value="<?php echo $m_name;?>">
                </div>
                <div class="form-group" >
                    <label>Quantity</label>
                    <input type="number" name = "quantity"  class="form-control" value="<?php echo $m_quantity;?>">
                </div>
                <div class="form-group" >
                    <label>Category</label>
                    <input type="text" name = "category"  class="form-control" value="<?php echo $m_category;?>">
                </div>
                <div class="form-group" >
                    <label>Rate</label>
                    <input type="number" name = "rate"  class="form-control" value="<?php echo $m_rate;?>">
                </div>
                <div class="submitclass">
                    <button type="submit" class="btn" name="submit"><h4>Update</h4></button>
                </div>
                <div class="back">
                    <button ><a href="./manipulate.php">Back</a></button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>